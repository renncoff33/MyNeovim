vim.cmd [[packadd packer.nvim]]
return require("packer").startup({function()
	use 'wbthomason/packer.nvim'
	use "olimorris/onedarkpro.nvim"
  use 'glepnir/galaxyline.nvim'
  use 'kyazdani42/nvim-tree.lua'
  use "lukas-reineke/indent-blankline.nvim"
  use 'Pocco81/auto-save.nvim'
  use 'tpope/vim-surround'
  use 'captbaritone/better-indent-support-for-php-with-html'
  use 'p00f/nvim-ts-rainbow'
  use 'windwp/nvim-ts-autotag'
  use 'windwp/nvim-autopairs'
  use 'neovim/nvim-lspconfig'
	use 'hrsh7th/cmp-nvim-lsp'
  use 'hrsh7th/cmp-nvim-lsp-signature-help'
	use 'hrsh7th/cmp-buffer'
	use 'hrsh7th/cmp-path'
	use 'hrsh7th/nvim-cmp'
	use 'L3MON4D3/LuaSnip'
	use 'saadparwaiz1/cmp_luasnip'
	use 'onsails/lspkind.nvim'
  use 'williamboman/nvim-lsp-installer'
  use 'nvim-treesitter/nvim-treesitter'
  use {'akinsho/bufferline.nvim', tag = "v2.*", requires = 'kyazdani42/nvim-web-devicons'}
  use 'nvim-telescope/telescope.nvim'
  use 'nvim-lua/plenary.nvim'
end,
config = {
  display = {
	  open_fn = function()
      return require('packer.util').float({ border = 'single' })
    end
  }
}})	
