require'nvim-treesitter.configs'.setup {
  highlight = {
    enable = true,
    additional_vim_regex_highlighting = false
    },
  rainbow = {
    enable = false,
    extended_mode = true,
    filetypes = {"javascript"}
    },
    autotag = {
    enable = true,
    filetypes = { "javascript"}
  }
}
