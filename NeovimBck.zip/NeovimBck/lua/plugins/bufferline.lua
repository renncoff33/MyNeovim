require("bufferline").setup{
  highlights = {
    buffer_selected = {
      bold = false,
      italic = false,
    }, 
  }
}
