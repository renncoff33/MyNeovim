require('nvim-autopairs').setup({
  enable_check_bracket_line = false
})

require("nvim-tree").setup()
