require("onedarkpro").setup({
    dark_theme = "onedark"
})
